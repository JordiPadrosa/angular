export { Article };

class Article{
    constructor(codi, nom, quantitat, preu, total) {
        this.codi = codi;
        this.nom = nom;
        this.quantitat = quantitat;
        this.preu = preu;
        this.total = total;
    }
}

