export { Factura };

class Factura{
    constructor(codi, nom, quantitat, preu, total) {
        this.codi = codi;
        this.nom = nom;
        this.quantitat = quantitat;
        this.preu = preu;
    }
}

