import { ICarta } from "./ICarta";
export interface ICartaSetIMig extends ICarta {
    value: number;
}
