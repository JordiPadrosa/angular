export interface ICarta {
    num: number;
    pal: string;
    img: string;
}