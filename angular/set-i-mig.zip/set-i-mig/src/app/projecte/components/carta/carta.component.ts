import { Component, Input, OnInit } from '@angular/core';
import { CartaSetIMig } from '../../model/entitats/implementacions/carta/CartaSetIMig';

@Component({
  selector: 'app-carta',
  templateUrl: './carta.component.html',
  styleUrls: ['./carta.component.css']
})
export class CartaComponent implements OnInit {

  @Input() carta!: CartaSetIMig;

  constructor() {
    
  }
  @Input()

  ngOnInit(): void {
    console.log(this.carta);
  }



}
