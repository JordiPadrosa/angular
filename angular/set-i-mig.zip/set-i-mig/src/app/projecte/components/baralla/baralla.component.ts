import { Component, OnInit } from '@angular/core';
import { __generator } from 'tslib';
import { Baralla } from '../../model/entitats/implementacions/baralla/Baralla';
import { BarallaSetIMig } from '../../model/entitats/implementacions/baralla/BarallaSetIMig';
import { CartaSetIMig } from '../../model/entitats/implementacions/carta/CartaSetIMig';
import { ICartaSetIMig } from '../../model/entitats/interficies/carta/ICartaSetIMig';

@Component({
  selector: 'app-baralla',
  templateUrl: './baralla.component.html',
  styleUrls: ['./baralla.component.css']
})
export class BarallaComponent implements OnInit {
  baralla!: BarallaSetIMig;
  constructor() { }
  
  ngOnInit(): void {
    this.baralla = new BarallaSetIMig();
    console.log(this.baralla);
  }

}
