export const PAL = [
    {"pal": "PORRO", "imatge": "porro.png"},
    {"pal": "FALÇ", "imatge": "falç.png"},
    {"pal": "BOLET", "imatge": "bolet.png"},
    {"pal": "FOC", "imatge": "foc.png"}
]